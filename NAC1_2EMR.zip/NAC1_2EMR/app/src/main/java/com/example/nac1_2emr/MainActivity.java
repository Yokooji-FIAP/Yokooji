package com.example.nac1_2emr;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void about(View v){
        Intent intent = new Intent(this,About.class);
        startActivity(intent);
    }
    public void MercadoLivre(View v){
        Intent intent = new Intent(this,MercadoLivreActivity.class);
        startActivity(intent);
    }
    public void Amazon(View v){
        Intent intent = new Intent(this,AmazonActivity.class);
        startActivity(intent);
    }
    public void AliExpress(View v){
        Intent intent = new Intent(this,AliExpressActivity.class);
        startActivity(intent);
    }
    public void Etsy(View v){
        Intent intent = new Intent(this,EtsyActivity.class);
        startActivity(intent);
    }
}
